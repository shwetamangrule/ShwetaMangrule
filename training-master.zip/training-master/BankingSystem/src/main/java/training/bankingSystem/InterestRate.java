package training.bankingSystem;

public class InterestRate {
	int interestRate;
	
	public int getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(int interestRate) {
		interestRate=8;
		this.interestRate = interestRate;
	}

	

}
