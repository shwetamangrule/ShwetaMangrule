package simplejava.bank;

public class Period {

	int period=12;

	public int getPeriod()
	{
		return period;
	}

	public void setPeriod(int period)
	{
		this.period = period;
	}

}