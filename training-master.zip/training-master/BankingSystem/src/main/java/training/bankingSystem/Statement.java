package training.bankingSystem;

import java.sql.Date;

public class Statement {
	
	Date date;
	String content;
	
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	

}
