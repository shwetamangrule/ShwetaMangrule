package training.bankingSystem;
/*
 * entity class for money
 */
public class Money {
	
	int money;
	
	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		money=500;
		this.money = money;
	}


}
