package simplejava.bank;

public class InterestRate {
	int interestRate=5;
	
	public int getInterestRate()
	{
		return interestRate;
	}

	public void setInterestRate(int interestRate) 
	{
		this.interestRate = interestRate;

	}

}