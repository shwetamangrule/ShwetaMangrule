package training.testing;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class TestFileIO {

	@Test
	public void checkpalindrone()

	{
		FileIO test = new FileIO(); // Palindrome program to test

		// assert statements
		assertEquals("output.txt", , message);(, actual, message);
		assertNotEquals("false", 12345, test.testPalindrome(12345));
		
	}
}
