package study.lambda;

public interface PrimeCheck {

	public boolean isPrime(int number);
}
