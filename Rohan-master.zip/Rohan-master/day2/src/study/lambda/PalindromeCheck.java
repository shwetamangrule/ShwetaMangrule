package study.lambda;

public interface PalindromeCheck {

	public boolean isPalindrome(int number);
	
}
