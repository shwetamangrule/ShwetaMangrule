package study.reorganize;


public class UserReorganize { //class UserOrganize is a driver class for ReorganizeString

	public static void main(String[] args) {
		
		ReorganizeString reorganize=new ReorganizeString();
		reorganize.reorganizeString();

	}

}
