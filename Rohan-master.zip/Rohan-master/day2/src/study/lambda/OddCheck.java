package study.lambda;

interface OddCheck{
	
	public boolean isOdd(int number);
	
}
