package com.training.retailerboot.exception;

public class Exception extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4609214656905222390L;

public Exception(String message)
{
	super(message);
	}
	

}
