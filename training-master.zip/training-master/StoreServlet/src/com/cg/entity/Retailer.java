package com.cg.entity;


public class Retailer {
	private int retailerId;
	public int getRetailerId() {
		return retailerId;
	}
/*	public void setRetailerId(int retailerId) {
		this.retailerId = retailerId;
	}*/
	private String retailerName;
	private String retailerAddress;
	public String getRetailerName() {
		return retailerName;
	}
	/*public void setRetailerName(String retailerName) {
		this.retailerName = retailerName;
	}
*/	public String getRetailerAddress() {
		return retailerAddress;
	}
	/*public void setRetailerAddress(String retailerAddress) {
		this.retailerAddress = retailerAddress;
	}*/
	/**
	 * @param retailerName
	 * @param retailerAddress
	 */
	
	/**
	 * 
	 */
	/*public Retailer() {
		super();
	}*/
	public Retailer(int retailerId, String retailerName, String retailerAddress) {
		super();
		this.retailerId = retailerId;
		this.retailerName = retailerName;
		this.retailerAddress = retailerAddress;
	}
	


}


	
