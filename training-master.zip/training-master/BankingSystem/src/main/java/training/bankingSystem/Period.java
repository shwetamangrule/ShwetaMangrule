package training.bankingSystem;

public class Period {

	public int getPeriod() {
		return period;
	}

	public void setPeriod(int period) {
		period=4;
		this.period = period;
	}

	int period=0;
}
