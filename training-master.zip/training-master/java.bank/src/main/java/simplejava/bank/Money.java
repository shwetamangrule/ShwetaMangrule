package simplejava.bank;

public class Money {

	float money=100;

	public float getMoney() 
	{
		return money;
	}

	public void setMoney(float money)
	{
		this.money = money;
	}

}	