package com.practice.jb.mesasanger.exception;

public class DataNotFound extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7026870738020507411L;

	public DataNotFound(String message)
	{
		super(message);
	}
}
