package com.cg.exception;

public class StoreException extends RuntimeException {

	private static final long serialVersionUID = 6123250935009969667L;

	public StoreException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
